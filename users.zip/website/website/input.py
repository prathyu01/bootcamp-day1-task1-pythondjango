from website.forms import PostForm

def post_form_upload(request):
    if request.method == 'GET':
        form = PostForm()
    else:
        form = PostForm(request.POST) # Bind data from request.POST into a PostForm
#  If data is valid, proceeds to create a new post and redirect the user
        if form.is_valid():
            content = form.cleaned_data['content']
            created_at = form.cleaned_data['created_at']
            post = m.Post.objects.create(content=content,
                                         created_at=created_at)
        return HttpResponseRedirect(reverse('post_detail',
                                            kwargs={'post_id': post.id}))

    return render(request, 'post/post_form_upload.html', {
        'form': form,
    })